<%-- 
    Document   : signup
    Created on : Mar 18, 2026, 12:45:05 PM
    Author     : jobre
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Sign up</title>
    </head>
    <body>
        <h1>Sign up</h1>
        <h2>
            Let's get started by entering a few details below!
        </h2>
        <form action="SignUpServlet" method="POST">
            <table>
                <tr><td>
                    <input type="text" name="name" required="" placeholder="First Name"/>
                    </td>    
                </tr>
                <tr>
                    <td>
                    <input type="text" name="surname" required="" placeholder="Last Name"/>
                </td>  
                </tr>
                <tr>
                    <td>
                    <input type="text" name="email" required="" placeholder="Email"/>
                </td>  
                </tr>
                <tr>
                    <td>
                    <input type="text" name="phone" required="" placeholder="Phone Number"/>
                </td>  
                </tr>
                <tr>
                    <td>
                        <input type="password" name="password" placeholder="Create Password" required=""/>
                            
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="password" name="confirmPassword" placeholder="Confirm Password" required=""/>
                            
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="submit" value="NEXT"/>
                    </td>
                    
                </tr>
            </table>
        </form>
    </body>
</html>
