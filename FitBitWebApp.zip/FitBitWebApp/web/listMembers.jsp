<%-- 
    Document   : listMembers
    Created on : Mar 18, 2026, 1:00:28 AM
    Author     : jobre
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Gym Members</title>
    </head>
    <body>
        <h2>FitBit Gym Members</h2>
       
        <table>
            <tr>
                <th>
                    ID
                </th>
                <th>
                    Name
                </th>
                <th>
                    surname
                </th>
                <th>
                    Email
                </th>
                <th>
                    Action
                </th>
            </tr>
            <%
                List<Member> list = (List<Member>) request.getAttribute("memberList");
                
                if(list != null){
                for(Member m : list){
                %>
                <tr>
                    <td>
                        <%= m.getMemberId()%>
                    </td>
                    <td>
                        <%= m.getName()%>
                    </td>
                    <td>
                        <%= m.getSurname()%>
                    </td>
                    <td>
                        <%= m.getEmail%>
                    </td>
                    <td>
                        <a href="DeleteMemberServlet?id=id<%=m.getMemberId()%>" onclick="return confirm('Are you dure you want to delete this member?');">
                        Delete</a>
                    </td>
                </tr>
                <%
                    }
}
%>
                
                }
                }
        </table>
    </body>
</html>
