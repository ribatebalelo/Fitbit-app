<%-- 
    Document   : login
    Created on : Mar 18, 2026, 12:22:49 PM
    Author     : jobre
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Login</title>
    </head>
    <body>
        <h1>SIGN IN</h1>
        
        <form action="SignInServlet" method="POST">
            <table>
                <tr>
                   <td>
                    Enter your email
                    </td>
                    
                </tr>
                <tr>
                <td>
                        <input type="text" name="email" required=""/></td>
                
                </tr>
                <tr>
                   <td>
                    Enter your your password
                    </td>
                    
                </tr>
                <tr>
                <td>
                    <input type="password" name="password" required=""/></td>
                
                </tr>
                <tr>
                    <td>
                        <input type="submit" value="Continue"/>
                    </td>
                </tr>
                <tr>
                    <td>
                        <a href="ForgotPasswordServlet">Forgot password?</a>
                    </td>
                </tr>
                <tr>
                    <td>
                        Don't have an account? <a href="signup.jsp">Sign up</a>
                    </td>
                </tr>
                
            </table>
        </form>
    </body>
</html>
