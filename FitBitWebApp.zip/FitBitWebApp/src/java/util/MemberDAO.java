/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

import java.sql.*;
import java.util.*;
import model.Member;
import util.DBConnection;

public class MemberDAO {

    public static List<Member> getAllMembers(){
        
        List<Member> list = new ArrayList<>();
        
        try{
            Connection con = DBConnection.getConnection();
            String sql = "SELECT * FROM member";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                Member m = new Member();
                m.setMemberId(rs.getInt("member_id"));
                m.setName(rs.getString("name"));
                m.setSurname(rs.getString("surname"));
                m.setEmail(rs.getString("email"));
                m.setPhone(rs.getString("phone"));
                m.setMembershipPlan(rs.getString("membership_plan"));
                m.setMembership_status(rs.getString("membership_status"));
                
                list.add(m);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return list;
    }
    public static void deleteMember(int id){
        try{
            Connection con = DBConnection.getConnection();
            String sql = "DELETE FROM member WHERE member_id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
}
